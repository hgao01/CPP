

#include <iostream>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>

/* all the arguments from command line, global variables */

   int                     m ;
   int                     k ;
   int                     n ;
   int                     s ;
   int                     MAX_UPDATE ;
   int                     MAX_REFILL ; // milliseconds
   int                     MAX_EXERCISE;       //milliseconds
   int                     c ;    
/* */
/*
const	int			m = 3;
const 	int			k = 5;
const 	int			n = 3;
const 	int			s = 2;
const 	int			MAX_UPDATE=800 ;
const	int			MAX_REFILL=801 ; // milliseconds
const	int 			MAX_EXERCISE=803;	//milliseconds
const 	int			c =5;
*/


int			chlk_cnt;		// total c
int *	 		team_cnt;		//how many
int *	 		team;		// team id
int *			occupant;
int			all_done=0;

long  * 			team_time;

struct ScoreBoard {
float *			each_score;
float *			team_score;  // m team
int			wgid;
int			wtid;
} sb;


pthread_mutex_t	*	mu_appr;		// from 1 to K
pthread_mutex_t		mu_score;
pthread_mutex_t		mu_c;
pthread_mutex_t		mu_o;
pthread_mutex_t		mu_t;			// for team time
pthread_mutex_t	*	mutex_s;
pthread_cond_t		cv_chlk;
pthread_cond_t	*	cv_myscore;
sem_t 	*		se_scores;		
sem_t   *		se_judge;




	
void 	*	gymnst( int arg)
{

timespec	tv0,tv1;

int	id  = (int) arg;
int	myp =0;
int	k_num =0;

// join a team randomly
int teamno= 1+ rand() % m ;

while( team_cnt[ teamno ] >= n)
{
    teamno=teamno % m;
    teamno++;
    }

team [ id  ] = teamno;
team_cnt[ teamno ] ++;		// n people

cout<<"Gymnast "<<id <<" is in team # "<<teamno<<endl;
sleep(1); // display nice

// randomly goto apparatus # k_num 

k_num = 1+ (rand() % k );

while( ++myp<=k ) {

pthread_mutex_lock( &mu_c);
while( chlk_cnt <= 0 )
pthread_cond_wait( &cv_chlk, &mu_c );

chlk_cnt--;	// use a chalk
pthread_mutex_unlock( &mu_c );



pthread_mutex_lock( &mu_appr[ k_num ] );

// wait judge back from previous scoring
sem_wait( &se_judge[ k_num ] );

// exercising

pthread_mutex_lock( &mu_o );
occupant[ k_num ] = id;		// controlled
pthread_mutex_unlock( &mu_o );

// cout<<"Gym "<<id<<" plays appr. "<<k_num <<" "<<myp<<endl;

// time taken to perform each exercise in milliseconds;

long ll0;
int	it0;

it0 = rand() % MAX_EXERCISE;
ll0 = (long) it0 * (long) 1000;

tv0.tv_sec=( time_t )0;
tv0.tv_nsec = ll0;
tv1.tv_sec =0;
tv1.tv_nsec = 0;

nanosleep( &tv0, &tv1 );    

if( tv1.tv_nsec>0 && tv1.tv_nsec<=tv0.tv_nsec )   // valid time used
 ll0 = tv0.tv_nsec-tv1.tv_nsec;

 pthread_mutex_lock( &mu_t );
 team_time[ teamno ] +=ll0;
 pthread_mutex_unlock( &mu_t );


// tell judge giving score
sem_post( &se_scores[ k_num ] );  //increase

//wait for her score

pthread_mutex_lock( &mutex_s[ k_num ]);
while( sb.each_score[ (id -1)*(k+1) + k_num ] <9.0 )
pthread_cond_wait( &cv_myscore[ k_num ], &mutex_s[ k_num ] );
pthread_mutex_unlock( &mutex_s[ k_num ] );

//leave the apparatus
pthread_mutex_unlock( &mu_appr[ k_num ] );

 k_num ++;
if( k_num> k ) k_num =1;

} //end while

}


void 	*	judge( void * argj )
{
	int idj = (int) argj;
	int gyms =0;
	int gymid;
	timespec	tv0,tv1;

	cout<<"Judge thread # "<< idj<<endl;

do {

sem_wait( &se_scores[ idj ] );	// wait gym to finish
gymid= occupant[ idj ];		// who uses ap

//goto score board
//lock score board mutex
pthread_mutex_lock( &mu_score );

sb.each_score[(gymid-1)*(k+1) + idj ] = 9.0 + ( rand() % 100 ) /99.0;
int t0 = team[ gymid ];
sb.team_score[ t0 ] += sb.each_score[ (gymid-1)*(k+1) + idj ];

pthread_mutex_unlock( &mu_score );

// scoreboard update requires a time [0, MAX_UPDATE] milliseconds;

tv0.tv_sec=( time_t )0;
tv0.tv_nsec = (long) 1000 * rand() % MAX_UPDATE;
tv1.tv_sec =0;
tv1.tv_nsec = 0;

nanosleep( &tv0, &tv1 );    

//tells gym her score is ready
pthread_mutex_lock( &mutex_s[ idj ] );
pthread_cond_signal( &cv_myscore[ idj ] );
pthread_mutex_unlock( &mutex_s[ idj ] );

//cout<<"\t\t\tJudge "<<idj <<": gym "<<gymid<<"=";

// go back to his apparatus
sem_post( &se_judge[ idj ] );



//for all m*n gymnasts

} while( ++gyms< m*n && all_done == 0 );

}

void	*	supplier( void * args )
{

timespec	tv0;
timespec	tv1;

int ids = (int) args;
cout<<"Chalk supplier thread # "<<ids<<" "<<endl;

while( all_done == 0 ) {

//add bags after MAX_REFILL milliseconds


tv0.tv_sec=( time_t )0;
tv0.tv_nsec = (long) 1000 * rand() % MAX_REFILL;
tv1.tv_sec =0;
tv1.tv_nsec = 0;

nanosleep( &tv0, &tv1 );

if ( chlk_cnt <c  ) 
{

pthread_mutex_lock( &mu_c);
chlk_cnt =c;

pthread_cond_broadcast( &cv_chlk );
pthread_mutex_unlock( &mu_c );

}

} // end while

}


int	main ( int argc,  char* argv[] )
{

if ( argc != 9 ) {
cout<<"\nFormat: Olympia n m k c s MAX_EXERCISE MAX_UPDATE MAX_REFILL \n";
exit( 1);
	}

                  m = atoi( argv[2]);
                  k = atoi ( argv[3] );
                  n = atoi( argv[1]);
                  s = atoi ( argv[5] );
                  MAX_UPDATE= atoi ( argv[ 7 ] );
                  MAX_REFILL= atoi ( argv[ 8 ] );
                  MAX_EXERCISE= atoi ( argv[ 6 ] );
                  c = atoi ( argv[ 4 ] );

chlk_cnt 	= c;

team_cnt 	= new (int) [ m+1 ];
team		= new (int) [ n*m +1 ];
occupant	= new (int) [ n*m +1 ];
team_time	= new (long) [ m+1 ];

sb.each_score  	= new (float) [ n*m*( k+1) ];  // total (n*m-1)*(k+1)+k 
sb.team_score	= new (float) [ m+1 ];

mu_appr		= new (pthread_mutex_t) [ k+1 ];
mutex_s		= new (pthread_mutex_t) [ k+1 ];
cv_myscore	= new (pthread_cond_t)  [ k+1 ];
se_scores	= new (sem_t)           [ k+1 ];
se_judge	= new (sem_t)		[ k+1 ];

pthread_t	* tid_g;
pthread_t	* tid_j;
pthread_t	* tid_s;

cout<<"Please enter a seed int for srand() :";
int sr0;
cin>>sr0;
srand( sr0);

tid_g = new (pthread_t) [ m*n +1 ];
tid_j = new (pthread_t) [ k +1 ];
tid_s = new (pthread_t) [ s+1 ];

int 	i,j;

for ( i=1; i<=k; i++ ) sem_init( &se_scores[ i ], 0, 0  );
for ( i=1;i<=k;  i++ ) sem_init( &se_judge[  i],  0, 1 );
for ( i=0;i<=m*n; i++)
{
			for( j=1;j<=k;j++) sb.each_score[(i-1)*(k+1)+j]=0.0;
			};

for(i=1; i<= m*n; i++) 
	pthread_create( &tid_g[ i ], NULL, gymnst, (void *) i );

for(i=1;i<=k;i++ ) 
	pthread_create( &tid_j[ i ], NULL, judge,  (void * ) i);

for( i=1;i<=s;i++) 
	pthread_create( &tid_s[ i ], NULL, supplier, (void * ) i );

sleep(1);
//to end all threads

for(i=1; i<=m; i++ )			// wait for team i to finish
for( j=1;j<=n*m; j++ ) {
	if( i== team[ n*m ] ) pthread_join( tid_g[ j], NULL );
	}

all_done = 1;
cout<<endl<<"ALL DONE!"<<endl;

for(i=1; i<=k; i++ )		pthread_join( tid_j[ i], NULL );

// declares the medal winners
float s0 = 0.0;
float s1 = 0.0;
int	l;

for( l=1; l<=m; l++ ) {
for( i=1; i<=n; i++ ) {
for( j=1; j<=k; j++ ) {
	sb.each_score[ ( n*(l-1)+i  -1)*(k+1) +0 ] +=sb.each_score[ (n*(l-1)+i-1)*(k+1)+ j];
	}
	// cout<<"Gym #"<<i+n*(l-1)<<"="<<sb.each_score[ (i*l-1)(k+1)+0]<<" ";
	} // end for i;

	// Outputs the final score of each team
	cout<<" Team #"<<l<<" total score is "<<sb.team_score[ l ]<<endl;
	cout<<" Team #"<<l<<" total exercise time is "<<team_time[ l ]/1000<<" milliseconds."<<endl;
	if( s1< sb.team_score[l ] ) { s1 = sb.team_score[ l ];
	sb.wtid = l;}
	}; // end for l

for ( i=1;i<=m*n; i++) {
	if( s0 < sb.each_score[(i-1)*(k+1)+0] ) {
		s0=sb.each_score[(i-1)*(k+1)+ 0];
		sb.wgid= i;
		};
}; 
	

cout<<" There are total "<<n*m<<" Gymnasts in "<<m<<" teams."<<endl;
cout<<" The individual winer is Gymnast #"<<sb.wgid<<" total="<<s0<<endl;
cout<<" The team       winer is Team    #"<<sb.wtid<<endl;

for(i=1; i<=s; i++ )		pthread_join( tid_s[ i], NULL );

return 0;
}
