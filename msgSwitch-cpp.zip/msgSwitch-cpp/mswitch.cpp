#include <iostream.h>
#include <vxWorks.h>
#include <semLib.h>
#include <timers.h>
#include <sockLib.h>
#include <inetLib.h>
#include <strLib.h>
#include "mswitchLayer.h"
#include "bufferControl.h"

// buffers
SMALL_BUFFER smallBuffer[SMALL_BUFFER_LENGTH];
MID_BUFFER midBuffer[MID_BUFFER_LENGTH];
LARGE_BUFFER largeBuffer[LARGE_BUFFER_LENGTH];

// buffer control array
BUFFER_CNTL_ARRAY * smallArray = new BUFFER_CNTL_ARRAY(SMALL_BUFFER_LENGTH);
BUFFER_CNTL_ARRAY * midArray = new BUFFER_CNTL_ARRAY(MID_BUFFER_LENGTH);
BUFFER_CNTL_ARRAY * largeArray = new BUFFER_CNTL_ARRAY(LARGE_BUFFER_LENGTH);

// buffer control block table
BUFFER_CONTROL_BLOCK bufferCntlTable[SMALL_BUFFER_LENGTH + MID_BUFFER_LENGTH + LARGE_BUFFER_LENGTH];

// semaphore for buffer
SEM_ID bufCntlSem = semMCreate(SEM_Q_PRIORITY | SEM_DELETE_SAFE | SEM_INVERSION_SAFE);

// timer
SEM_ID timerSemId = semMCreate(SEM_Q_PRIORITY | SEM_DELETE_SAFE | SEM_INVERSION_SAFE);
LIST * timerList;

// Socket
LIST * socketList;
#define SERVER_MAX_CONNECTIONS	4

int getReceiver(int index);
int checkRemote(int index);
char * getData (int index);
int getPayloadLength(int index);
void insertNode(TIMER_NODE * node, LIST * list);
BUFFER_HEADER * getBufferHeader(int index);
void timerManager(int instance);
void timerHandler(timer_t timerid, int arg);
void timer(int instance, int startSec,int startNenoSec, int repeatSec, int repeatNenoSec, VOIDFUNCPTR routine);
SOCKET_NODE * sFdFind(int ip, int port);
void socketTask(int sFd);
void releaseBuffer(int index);
int reserveBuffer(int dataSize);

void mswitch_task(int instance);
void mswitch_task1(int instance);

//CMS_task cms_task[CMS_TASK_COUNT];


/****************************************************************************************************************
*bufferCntlInit()
*	Initialize the buffer control block table
*
*****************************************************************************************************************/
void bufferCntlInit() {
	int i;
	int j;

	for (i = 0; i < SMALL_BUFFER_LENGTH; i++) {
		bufferCntlTable[i].bufferSize = SMALL_BUFFER_SIZE;
		bufferCntlTable[i].bufferType = SMALL_BUFFER_TYPE;
		bufferCntlTable[i].bufferState = BUFFER_IDLE;
		bufferCntlTable[i].ownerTaskId = -1;
		bufferCntlTable[i].timeoutPtr = NULL;
		bufferCntlTable[i].bufferPtr = (char *)(&(smallBuffer[i]));

		// temp change to ip + port#
		/*********************************************
		smallBuffer[i].header.srcNode.nodeId = -1;
		smallBuffer[i].header.srcNode.zoneNum = -1;
		smallBuffer[i].header.dstNode.nodeId = -1;
		smallBuffer[i].header.dstNode.zoneNum = -1;
		**********************************************/
		smallBuffer[i].header.srcNode.ip = 0;
		smallBuffer[i].header.srcNode.port = -1;
		smallBuffer[i].header.dstNode.ip = 0;
		smallBuffer[i].header.dstNode.port = -1;
	}

	for (i = SMALL_BUFFER_LENGTH, j = 0; i < SMALL_BUFFER_LENGTH + MID_BUFFER_LENGTH; i++, j++) {
		bufferCntlTable[i].bufferSize = MID_BUFFER_SIZE;
		bufferCntlTable[i].bufferType = MID_BUFFER_TYPE;
		bufferCntlTable[i].bufferState = BUFFER_IDLE;
		bufferCntlTable[i].ownerTaskId = -1;
		bufferCntlTable[i].timeoutPtr = NULL;
		bufferCntlTable[i].bufferPtr = (char *)(&(midBuffer[j]));

		// temp change to ip + port
		/******************************************
		midBuffer[j].header.srcNode.nodeId = -1;
		midBuffer[j].header.srcNode.zoneNum = -1;
		midBuffer[j].header.dstNode.nodeId = -1;
		midBuffer[j].header.dstNode.zoneNum = -1;
		*******************************************/
		midBuffer[j].header.srcNode.ip = 0;
		midBuffer[j].header.srcNode.port = -1;
		midBuffer[j].header.dstNode.ip = 0;
		midBuffer[j].header.dstNode.port = -1;
	}

	for (i = SMALL_BUFFER_LENGTH + MID_BUFFER_LENGTH, j = 0; i < SMALL_BUFFER_LENGTH + MID_BUFFER_LENGTH + LARGE_BUFFER_LENGTH; i++, j++) {
		bufferCntlTable[i].bufferSize = LARGE_BUFFER_SIZE;
		bufferCntlTable[i].bufferType = LARGE_BUFFER_TYPE;
		bufferCntlTable[i].bufferState = BUFFER_IDLE;
		bufferCntlTable[i].ownerTaskId = -1;
		bufferCntlTable[i].timeoutPtr = NULL;
		bufferCntlTable[i].bufferPtr = (char *)(&(largeBuffer[j]));

		// temp change to ip + port
		/*******************************************
		largeBuffer[j].header.srcNode.nodeId = -1;
		largeBuffer[j].header.srcNode.zoneNum = -1;
		largeBuffer[j].header.dstNode.nodeId = -1;
		largeBuffer[j].header.dstNode.zoneNum = -1;
		********************************************/
		largeBuffer[j].header.srcNode.ip = 0;
		largeBuffer[j].header.srcNode.port = -1;
		largeBuffer[j].header.dstNode.ip = 0;
		largeBuffer[j].header.dstNode.port = -1;
	}
}

/****************************************************************************************************************
*getBuffer()
*	reserve the buffer
*
*input:
*	bufferSize - buffer size
*	bufferPointer - pointer to the buffer
*
*return:
*	index of buffer control block table if ok, -1 if error
*
*****************************************************************************************************************/
int getBuffer(int bufferSize, char *& bufferPointer) {
	int index;

	index = reserveBuffer(bufferSize);

	// update buffer control block
	if (index != -1) {
		bufferCntlTable[index].bufferState = BUFFER_ALLOCATED;
		bufferPointer = bufferCntlTable[index].bufferPtr;
		int taskId = taskIdSelf();
		// search task control block table to get task index
		// copy task index into ownerTaskId
		for (int i = 0; i < (int)CMS_TASK_COUNT; i++) {
			if (cms_task[i].id == taskId) {
				bufferCntlTable[index].ownerTaskId = i;
				break;
			}
		}
	}

	return index;
}

/****************************************************************************************************************
*freeBuffer()
*	release the buffer
*
*input:
*	index - index of bufer control block table
*
*return:
*	OK or ERROR
*
*****************************************************************************************************************/
int freeBuffer(int index) {

	cout << "Call freeBuffer()" << endl;

	int arrayIndex;

	// check index
	if (index < 0 || index >= SMALL_BUFFER_LENGTH + MID_BUFFER_LENGTH + LARGE_BUFFER_LENGTH) {
		errnoSet(ERROR_INDEX);
		// ADD - raise log or/and alarm
		return ERROR;
	}

	// check buffer status
	if (bufferCntlTable[index].bufferState == BUFFER_IDLE) {
		errnoSet(ERROR_BUFFER_NOT_IN_USED);
		// ADD - raise log or/and alarm
		return ERROR;
	}

	// check the ownship
	int taskId = taskIdSelf();
	int taskIndex;
	for (int i = 0; i < (int)CMS_TASK_COUNT; i++) {
		if (cms_task[i].id == taskId) {
			taskIndex = i;
			break;
		}
	}

	if (taskIndex != bufferCntlTable[index].ownerTaskId) {
		errnoSet(ERROR_OWNERSHIP);
		return ERROR;
	}

	releaseBuffer(index);

	cout << "End freeBuffer()" << endl;

	return OK;
}


/****************************************************************************************************************
*sendMessage()
*	send message to destination task through message queue or through socket if destination task is in
*	other node.
*
*input:
*	index - index of bufer control block table
*	timeout - WAIT_FOREVER, NO_WAIT, or ticks to wait, default option is NO_WAIT
*	priority - MSG_PRI_NORMAL, or MSG_PRI_URGENT, default option is MSG_PRI_NORMAL
*
*return:
*	OK or ERROR
*
*****************************************************************************************************************/
int sendMessage(int index, int timeout = NO_WAIT, int priority = MSG_PRI_NORMAL){

	cout << "start sendMessage" << endl;

	int receiver;
	int remote;		// 0 - inbound, 1 - outbound
	MSG_Q_ID msgId;
	int ret = OK;
	int sender;

	remote = checkRemote(index);

	if (remote == 0) {
		// send inbound message
		receiver = getReceiver(index);

		if (receiver < 0 || receiver >= CMS_TASK_COUNT) {
			freeBuffer(index);
			errnoSet(ERROR_DST_TASK_ID);
			cout << "dst task id incorrect" << endl;
			return ERROR;
		}

		bufferCntlTable[index].bufferState = BUFFER_INTERNAL_ROUTE;
	} else {
		// send outbound message
		receiver = SOCKET_CLIENT;
		bufferCntlTable[index].bufferState = BUFFER_EXTERNAL_ROUTE;
	}

	msgId = cms_task[receiver].mq_id;
	sender = bufferCntlTable[index].ownerTaskId;
	bufferCntlTable[index].ownerTaskId = receiver;

	if (msgQSend(msgId, (char *)&index, sizeof(index), timeout, priority) == ERROR) {
		bufferCntlTable[index].ownerTaskId = sender;
		freeBuffer(index);
		errnoSet(ERROR_MSG_SEND);
		ret = ERROR;
	}

	cout << "end sendMessage" << endl;

	return ret;
}



/****************************************************************************************************************
*receiveMessage()
*	receive message from message queue
*
*input:
*	id - task id
*	timeout - WAIT_FOREVER, NO_WAIT, or ticks to wait
*	bufferPointer - pointer to the message buffer
*
*return:
*	index of bufer control block table
*
*****************************************************************************************************************/
int receiveMessage(int id, int timeout, char *& bufferPointer){
	MSG_Q_ID msgId = cms_task[id].mq_id;
	int index;

	if(msgQReceive(msgId, (char *)(&index), sizeof(index), timeout) == ERROR) {
		errnoSet(ERROR_MSG_RECEIVE);
		index = -1;
	}

	if (index != -1) {
		bufferPointer = (bufferCntlTable[index].bufferPtr);
	}

	return index;
}


/****************************************************************************************************************
*startTimer()
*	start timer
*
*input:
*	unit - time delay
*	index - index of buffer control block
*	repeat - 0 : single timeout, 1: repeat time out
*
*return:
*	timeout handle
*
*****************************************************************************************************************/
int startTimer(int unit, int index, int repeat = 0){
	TIMER_NODE * node = new TIMER_NODE;

	node->delay = unit;
	node->index = index;
	node->handle = index;
	node ->repeatFlag = repeat;
	if (repeat == 1)
		node->repeatDelay = unit;

	semTake(timerSemId, WAIT_FOREVER);
	insertNode(node, timerList);
	bufferCntlTable[index].bufferState = BUFFER_TIME_OUT;
	bufferCntlTable[index].timeoutPtr = (char *)node;
	semGive(timerSemId);
	return index;
}


/****************************************************************************************************************
*stopTimer()
*	stop timer
*
*input:
*	handle - time out handle
*
*return:
*	OK or ERROR
*
*****************************************************************************************************************/
int stopTimer(int handle){
	int ret = OK;
	TIMER_NODE * node = (TIMER_NODE *)(bufferCntlTable[handle].timeoutPtr);

	if (lstFind(timerList, (NODE *) node) == ERROR) {
		errnoSet(ERROR_TIMER_NODE_NOT_FOUND);
		ret = ERROR;
	} else {
		semTake(timerSemId, WAIT_FOREVER);
		lstDelete(timerList, (NODE *) node);
		semGive(timerSemId);

		delete node;
		freeBuffer(handle);
	}

	return ret;
}




/****************************************************************************************************************
*semaphoreCreate()
*	create and initialize a mutual-exclusion semaphore
*
*input:
*
*return:
*	SEM_ID or NULL
*
*****************************************************************************************************************/
SEM_ID semaphoreCreate(){
	return semMCreate(SEM_Q_PRIORITY | SEM_DELETE_SAFE | SEM_INVERSION_SAFE);
}


/****************************************************************************************************************
*semaphoreTake()
*	take a semaphore
*
*input:
*	id - semaphore id
*	timeout - WAIT_FOREVER, NO_WAIT, or ticks to wait
*
*return:
*	OK or ERROR
*
*****************************************************************************************************************/
int semaphoreTake(SEM_ID id, int timeout){
	return semTake(id, timeout);
}


/****************************************************************************************************************
*semaphoreGive()
*	give a semaphore
*
*input:
*	id - semaphore id
*
*return:
*	OK or ERROR
*
*****************************************************************************************************************/
int semaphoreGive(SEM_ID id){
	return semGive(id);
}


/****************************************************************************************************************
*semaphoreDelete()
*	delete a semaphore
*
*input:
*	id - semaphore id
*
*return:
*	OK or ERROR
*
*****************************************************************************************************************/
int semaphoreDelete(SEM_ID id){
	return semDelete(id);
}


/****************************************************************************************************************
*timer()
*	create and initialize timer
*
*input:
*	startSec - delay time by second before starting timer
*	startNenoSec - delay time by neno second before starting timer
*	repeatSec - timer expired time by second
*	repeatNenoSec - timer expired time by neno second
*	routine - timer handler
*
*****************************************************************************************************************/
void timer(int instance, int startSec,int startNenoSec, int repeatSec, int repeatNenoSec, VOIDFUNCPTR routine) {
	int ret;
	timer_t timer;
	struct itimerspec timerData;

	if (instance == 1) {
		/*
		 * First time initialization
		 */
		//taskDelay(sysClkRateGet() * 4);
		bufferCntlInit();

		/*
		 * During its first invocation, notify initialization module that it is done with local initialization,
		 * then suspend itself.
		 */
		CMS_set_init_status(TIMER, OK);
		semGive(cms_init_sem);
		taskSuspend(0);
	}

	if ((ret = timer_create(CLOCK_REALTIME, NULL, &timer)) == ERROR) {
		cout << "Can not create timer" << endl;
		exit(0);
	}

	if ((ret = timer_connect(timer, routine, 0)) == ERROR) {
		cout << "Can not connect to timer handler" << endl;
		exit(0);
	}

	timerData.it_value.tv_sec = startSec;
	timerData.it_value.tv_nsec = startNenoSec;
	timerData.it_interval.tv_sec = repeatSec;
	timerData.it_interval.tv_nsec = repeatNenoSec;
	if ((ret = timer_settime(timer, 0, &timerData, NULL)) == ERROR) {
		cout << "Can not start the Timer" << endl;
		exit(0);
	}

	while (1) {
		taskDelay(500);
	}
}

/****************************************************************************************************************
*timerHandler()
*	this function is timer handler
*
*input:
*
*
*****************************************************************************************************************/
void timerHandler(timer_t timerid, int arg) {
	//cout << "Timer is expired " << endl;

	int id = cms_task[TIMER_MANAGER].id;
	taskResume(id);
}


/******************************************************************************
*timerManager():
*	Monitor the timer list when timer is expired.
*
*******************************************************************************/
void timerManager(int instance) {
	cout << "[TimerManager] Start TimerManager" << endl;

	if (instance == 1) {
		/*
		 * First time initialization
		 */
		//taskDelay(sysClkRateGet() * 4);
		timerList = new LIST();
		lstInit(timerList);

		/*
		 * During its first invocation, notify initialization module that it is done with local initialization,
		 * then suspend itself.
		 */
		CMS_set_init_status(TIMER_MANAGER, OK);
		semGive(cms_init_sem);
		taskSuspend(0);
	}

	while (1) {
		taskSuspend(0);
		semTake(timerSemId, WAIT_FOREVER);
		if (lstCount(timerList) > 0) {
			//cout << "[TimerManager] update timer list" << endl;
			TIMER_NODE * node = (TIMER_NODE *)lstFirst(timerList);
			node->delay = node->delay - 1;
			if (node->delay == 0) {
				// Timeout, send timeout message to task
				cout << "[TimerManager] send timeout message to task" << endl;

				int count = lstCount(timerList);
				for (int i = 1; i <= count; i++) {
					TIMER_NODE * nextNode = (TIMER_NODE *) lstFirst(timerList);
					if (nextNode->delay == 0) {
						if (nextNode->repeatFlag == 0) {
							// single timeout
							sendMessage(nextNode->index, NO_WAIT, MSG_PRI_NORMAL);
						} else {
							// repeat timeout
							int length = getPayloadLength(nextNode->index);
							char * bufPtr;
							int index;
							BUFFER_HEADER * srcHeader;
							BUFFER_HEADER * dstHeader;
							char * srcPayload;
							char * dstPayload;

							if ((index = getBuffer(length, bufPtr)) == -1) {
								// raise alarm;
							} else {
								// copy data from src buffer to dst buffer
								srcHeader = getBufferHeader(nextNode->index);
								dstHeader = getBufferHeader(index);
								srcPayload = getData(nextNode->index);
								dstPayload = getData(index);
								memcpy(dstHeader, srcHeader, sizeof(BUFFER_HEADER));
								memcpy(dstPayload, srcPayload, length);
								sendMessage(index, NO_WAIT, MSG_PRI_NORMAL);


							}

							// create new timer node  and insert into timer list
							TIMER_NODE * newNode = new TIMER_NODE;
							newNode->delay = nextNode->repeatDelay;
							newNode->index = nextNode->index;
							newNode->handle = nextNode->handle;
							newNode->repeatFlag = nextNode->repeatFlag;
							newNode->repeatDelay = nextNode->repeatDelay;
							insertNode(newNode, timerList);
							bufferCntlTable[nextNode->index].timeoutPtr = (char *)newNode;
						}

						// remove first node
						lstDelete(timerList, nextNode);
						delete nextNode;
					} else {
						break;
					}
				}
			}
		} else {
			//cout << "[TimerManager] no timer request" << endl;
		}
		semGive(timerSemId);
	}
}


/****************************************************************************************************************
*getBufferHeader()
*	get the buffer header
*
*input:
*	index - index of bufer control block table
*
*return:
*	pointer to the buffer header
*
*****************************************************************************************************************/
BUFFER_HEADER * getBufferHeader(int index) {
	BUFFER_HEADER * header;
	switch (bufferCntlTable[index].bufferType) {
		case SMALL_BUFFER_TYPE :
			header = &(((SMALL_BUFFER *)(bufferCntlTable[index].bufferPtr))->header);
			break;
		case MID_BUFFER_TYPE :
			header = &(((MID_BUFFER *)(bufferCntlTable[index].bufferPtr))->header);
			break;
		case LARGE_BUFFER_TYPE :
			header = &(((LARGE_BUFFER *)(bufferCntlTable[index].bufferPtr))->header);
			break;
	}
	return header;
}


/****************************************************************************************************************
*getReceiver()
*	get the destination task id from buffer header
*
*input:
*	index - index of bufer control block table
*
*return:
*	destination task id
*
*****************************************************************************************************************/
int getReceiver(int index) {
	BUFFER_HEADER * header;
	header = getBufferHeader(index);
	return header->dstTaskId;
}



/****************************************************************************************************************
*getData()
*	get the payload from buffer
*
*input:
*	index - index of bufer control block table
*
*return:
*	pointer to the payload
*
*****************************************************************************************************************/
char * getData (int index) {
	char * data;
	switch (bufferCntlTable[index].bufferType) {
		case SMALL_BUFFER_TYPE :
			data = ((SMALL_BUFFER *)(bufferCntlTable[index].bufferPtr))->data;
			break;
		case MID_BUFFER_TYPE :
			data = ((MID_BUFFER *)(bufferCntlTable[index].bufferPtr))->data;
			break;
		case LARGE_BUFFER_TYPE :
			data = ((LARGE_BUFFER *)(bufferCntlTable[index].bufferPtr))->data;
			break;
	}

	return data;
}


/****************************************************************************************************************
*checkRemote()
*	check the buffer header to decide the message type (inbound or outbound)
*
*input:
*	index - index of bufer control block table
*
*return:
*	0 - inbound
*	1 - outbound
*
*****************************************************************************************************************/
int checkRemote(int index) {
	int remote;

	BUFFER_HEADER * header;
	header = getBufferHeader(index);

	// temp change to ip + port
	/*********************************************************************
	if (header->dstNode.nodeId == -1 || header->dstNode.zoneNum == -1)
		remote = 0;
	else
		remote = 1;
	**********************************************************************/
	if (header->dstNode.ip == 0 || header->dstNode.port == -1)
		remote = 0;
	else
		remote = 1;

	return remote;
}


/****************************************************************************************************************
*getPayloadLength()
*	get the payload length
*
*input:
*	index - index of bufer control block table
*
*return:
*	payload length
*
*****************************************************************************************************************/
int getPayloadLength(int index) {
	int length;
	BUFFER_HEADER * header;

	header = getBufferHeader(index);
	length = header->length - sizeof(BUFFER_HEADER);

	return length;
}


/****************************************************************************************************************
*insertNode()
*	insert timer node into timer list
*
*input:
*	node - pointer to the timer node
*	list - pointer to the timer list
*
*
*****************************************************************************************************************/
void insertNode(TIMER_NODE * node, LIST * list) {
	int count = lstCount(list);

	if (count == 0) {
		lstAdd(list, (NODE *) node);
	} else {
		TIMER_NODE * nodePtr = (TIMER_NODE *)lstFirst(list);
		while (nodePtr != NULL) {
			if (nodePtr->delay < node->delay) {
				node->delay = node->delay - nodePtr->delay;
			} else if (nodePtr->delay == node->delay) {
				node->delay = 0;
				lstInsert(list,(NODE *)nodePtr, (NODE *)node);
				break;
			} else {
				nodePtr->delay = nodePtr->delay - node->delay;
				TIMER_NODE * newNode = (TIMER_NODE *)lstPrevious((NODE *) nodePtr);
				lstInsert(list, (NODE *)newNode, (NODE *) node);
				break;
			}

			nodePtr = (TIMER_NODE *) lstNext((NODE *)nodePtr);
		}

		if (nodePtr == NULL) {
			nodePtr = (TIMER_NODE *)lstLast(list);
			lstInsert(list,(NODE *)nodePtr, (NODE *) node);
		}
	}
}


/******************************************************************************
*SocketClient():
*	Send message to other machine.
*
*******************************************************************************/
void socketClient(int instance) {
	char * buf;
	int index;
	BUFFER_HEADER * header;
	int ip;
	int port;
	int sFd;
	SOCKET_NODE * node = NULL;
	int newNodeFlag;
	SOCKET_NODE * newNode;
	int dataSize;
	char * message;

	if (instance == 1) {
		/*
		 * First time initialization
		 */
		//taskDelay(sysClkRateGet() * 4);

		/*
		 * During its first invocation, notify initialization module that it is done with local initialization,
		 * then suspend itself.
		 */
		CMS_set_init_status(SOCKET_CLIENT, OK);
		semGive(cms_init_sem);
		taskSuspend(0);
	}

	socketList = new LIST();
	lstInit(socketList);

	while (1) {
		if ((index = receiveMessage(SOCKET_CLIENT, WAIT_FOREVER,  buf)) == -1) {
			cout << "error - receiveMessage" << endl;
		} else {
			cout << "index = " << index << endl;
		}

		cout << "SocketClient got the message" << endl;

		header = getBufferHeader(index);

		ip = header->dstNode.ip;
		port = header->dstNode.port;

		cout << "ip = " << ip << endl;
		cout << "port = " << port << endl;

		if ((node = sFdFind(ip, port)) == NULL) {
			// create a new socket file descriptor
			struct sockaddr_in serverAddr;
			int sockAddrSize;

			// create socket
			if ((sFd = socket(AF_INET, SOCK_STREAM, 0)) == ERROR) {
				cout << "SocketClient: can not create socket" << endl;
			} else {
				cout << "SocketClient: create socket" << endl;
			}

			sockAddrSize = sizeof(struct sockaddr_in);
			bzero((char *) &serverAddr, sockAddrSize);
			serverAddr.sin_family = AF_INET;
			serverAddr.sin_len = (u_char) sockAddrSize;
			serverAddr.sin_port = htons(port);
			serverAddr.sin_addr.s_addr = ip;

			// connect to server
			if (connect(sFd, (struct sockaddr *) &serverAddr, sockAddrSize) == ERROR) {
				cout << "SocketClient: can not connect to server" << endl;
			} else {
				cout << "SocketClient: connect to server" << endl;
			}

			// add an node into socket list
			newNode = new SOCKET_NODE();
			newNode->ip = ip;
			newNode->port = port;
			newNode->sFd = sFd;
			lstAdd(socketList, (NODE *) newNode);
			newNodeFlag = 1;
		} else {
			// reuse socket file descriptor
			sFd = node->sFd;
			newNodeFlag = 0;
		}

		dataSize = header->length;
		message = new char[dataSize];

		memcpy(message, buf, dataSize);

		if (write(sFd, message, dataSize) == ERROR) {
			// delete socket node from socket list
			if (newNodeFlag == 1) {
				lstDelete(socketList, (NODE *)newNode);
				delete newNode;
			} else {
				lstDelete(socketList, (NODE *) node);
				delete node;
			}
			cout << "Can not send message" << inet_lnaof(ip) << endl;
		}

		freeBuffer(index);
		delete message;
	}
}

/**********************************************************************************
*sFdFind(int ip, int port)
*	search socket list to find the socket file descriptor.
*
*input:
*	ip - ip address
*	port - port #
*
*return
*	pointer to socket node or NULL if not found
*
***********************************************************************************/
SOCKET_NODE * sFdFind(int ip, int port) {
	SOCKET_NODE * node = NULL;
	int count;

	if ((count = lstCount(socketList)) > 0) {
		for (int i = 1; i <= count; i++) {
			node = (SOCKET_NODE *)lstNth(socketList, i);
			if (node->ip == ip && node->port == port)
			break;
		}
	}

	return node;
}


int socketTaskNum = 1;
/******************************************************************************
*socketServer():
*	Listen to other machine to set up socket connection.
*
*******************************************************************************/
void socketServer(int instance, int port) {
	struct sockaddr_in serverAddr;
	struct sockaddr_in clientAddr;
	int sockAddrSize;
	int sFd;
	int newFd;

	if (instance == 1) {
		/*
		 * First time initialization
		 */
		//taskDelay(sysClkRateGet() * 4);

		/*
		 * During its first invocation, notify initialization module that it is done with local initialization,
		 * then suspend itself.
		 */
		CMS_set_init_status(SOCKET_SERVER, OK);
		semGive(cms_init_sem);
		taskSuspend(0);
	}

	// set up the local address
	sockAddrSize = sizeof(struct sockaddr_in);
	bzero((char *) &serverAddr, sockAddrSize);
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_len = (u_char) sockAddrSize;
	serverAddr.sin_port = htons(port);
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

	// create socket
	if ((sFd = socket(AF_INET, SOCK_STREAM, 0)) == ERROR) {
		cout << "SocketServer: Can not create socket" << endl;
	} else {
		cout << "SocketServer: Socket is created" << endl;
	}

	// bind socket to local address
	if (bind(sFd, (struct sockaddr *) &serverAddr, sockAddrSize) == ERROR) {
		cout << "SocketServer : Can not bind to local address" << endl;
	} else {
		cout << "SocketServer: bind to local address" << endl;
	}

	// listen to the socket
	if (listen(sFd, SERVER_MAX_CONNECTIONS) == ERROR) {
		cout << "SocketServer : Can not listen to the socket" << endl;
	} else {
		cout << "SocketServer: listen to the socket" << endl;
	}

	while (1) {
		if ((newFd = accept(sFd, (struct sockaddr *) &clientAddr, &sockAddrSize)) == ERROR) {
			cout << "SocketServer: can not accept client" << endl;
		} else {
			cout << "SocketServer: accept client" << endl;
		}

		char taskName[100];

		sprintf(taskName, "SocketTask%d", socketTaskNum);
		socketTaskNum++;
		taskSpawn(taskName, 11, 0, 1000, (FUNCPTR)socketTask, newFd, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	}
}

/******************************************************************************
*socketTask():
*	Receive message from other machine.
*
*input:
*	sFd - socket file descriptor
*
*******************************************************************************/
void socketTask(int sFd) {
	int bufSize = sizeof(BUFFER_HEADER) + LARGE_BUFFER_SIZE;
	int size;
	int dataSize;
	int index;
	int taskId;
	MSG_Q_ID msgId;

	while (1) {
		char *buf = new char[bufSize];

		if ((size = read(sFd, buf, bufSize)) == ERROR) {
			cout << "Can not read data from other system" << endl;
			close(sFd);
			exit(0);
		}

		// get the buffer
		dataSize = size - sizeof(BUFFER_HEADER);
		index = reserveBuffer(dataSize);

		if (index == -1) {
			cout << "buffer is full" << endl;
		} else {
			memcpy(bufferCntlTable[index].bufferPtr, buf, size);
			taskId = getReceiver(index);

			if (taskId < 0 || taskId >= CMS_TASK_COUNT) {
				// release buffer
				releaseBuffer(index);
				cout << "dst task id incorrect" << endl;

			} else {
				// set buffer control block
				bufferCntlTable[index].bufferState = BUFFER_EXTERNAL_ROUTE;
				bufferCntlTable[index].ownerTaskId = taskId;

				// send the message to dst task
				msgId = cms_task[taskId].mq_id;
				if (msgQSend(msgId, (char *)&index, sizeof(index), NO_WAIT, MSG_PRI_NORMAL) == ERROR) {
					cout << "Can not send the message" << endl;
					releaseBuffer(index);
				}
			}
		}

		delete buf;
	}
}

/****************************************************************************************************************
*releaseBuffer()
*	free the buffer and reset the buffer control block
*
*input:
*	index - index of bufer control block table
*
*return:
*
*
*****************************************************************************************************************/
void releaseBuffer(int index) {
	semTake(bufCntlSem, WAIT_FOREVER);

	int arrayIndex;
	BUFFER_HEADER * header;

	header = getBufferHeader(index);

	// free buffer
	if (index < MID_BASE) {
		arrayIndex = index;
		smallArray->putEntry(arrayIndex);
	} else if (index < LARGE_BASE) {
		arrayIndex = index - MID_BASE;
		midArray->putEntry(arrayIndex);
	} else {
		arrayIndex = index - LARGE_BASE;
		largeArray->putEntry(arrayIndex);
	}

	// reset buffer control block
	bufferCntlTable[index].bufferState = BUFFER_IDLE;
	bufferCntlTable[index].ownerTaskId = -1;

	// reset buffer header

	// temp change to ip + port
	/********************************
	header->srcNode.nodeId = -1;
	header->srcNode.zoneNum = -1;
	header->dstNode.nodeId = -1;
	header->dstNode.zoneNum = -1;
	*********************************/
	header->srcNode.ip = 0;
	header->srcNode.port = -1;
	header->dstNode.ip = 0;
	header->dstNode.port = -1;

	semGive(bufCntlSem);
}

/****************************************************************************************************************
*reserveBuffer()
*	reserve the buffer
*
*input:
*	dataSize - data size
*
*return:
*	index of buffer control block, or -1 if out of buffers
*
*****************************************************************************************************************/
int reserveBuffer(int dataSize) {
	int index;

	semTake(bufCntlSem, WAIT_FOREVER);

	// find the available buffer
	if (dataSize <= SMALL_BUFFER_SIZE) {
		if (!smallArray->isEmpty()) {
			index = smallArray->getEntry();
		} else if (!midArray->isEmpty()) {
			index = MID_BASE + midArray->getEntry();
		} else if (!largeArray->isEmpty()) {
			index = LARGE_BASE + largeArray->getEntry();
		} else {
			errnoSet(ERROR_BUFFER_FULL);
			index = -1;
		}
	} else if (dataSize <= MID_BUFFER_SIZE) {
		if (!midArray->isEmpty()) {
			index = MID_BASE + midArray->getEntry();
		} else if (!largeArray->isEmpty()) {
			index = LARGE_BASE + largeArray->getEntry();
		} else {
			errnoSet(ERROR_BUFFER_FULL);
			index = -1;
		}
	} else if (dataSize <= LARGE_BUFFER_SIZE) {
		if (!largeArray->isEmpty()) {
			index = LARGE_BASE + largeArray->getEntry();
		} else {
			errnoSet(ERROR_BUFFER_FULL);
			index = -1;
		}
	} else {
		errnoSet(ERROR_BUFFER_SIZE);
		index = -1;
	}

	semGive(bufCntlSem);

	return index;
}


/**********************************************************************************
* testing only
***********************************************************************************/
void printBCB(int i) {
	cout << "bufferCntlTable[" << i << "].bufferSize = " << bufferCntlTable[i].bufferSize << endl;
	cout << "bufferCntlTable[" << i << "].bufferType = " << bufferCntlTable[i].bufferType << endl;
	cout << "bufferCntlTable[" << i << "].bufferState = " << bufferCntlTable[i].bufferState << endl;
	cout << "bufferCntlTable[" << i << "].ownerTaskId = " << bufferCntlTable[i].ownerTaskId << endl;
}

void printTimerList() {
	int count;
	semTake(timerSemId, WAIT_FOREVER);
	count = lstCount(timerList);
	if (count == 0) {
		cout << "empty list" << endl;
	} else {
		for (int i = 1; i <= count; i++) {
			TIMER_NODE * node = (TIMER_NODE *) lstNth(timerList, i);
			cout << "Node " << i << " time = " << node->delay << endl;
			cout << "handler = " << node->handle << endl;
		}
	}
	semGive(timerSemId);
}

/*************************************************************************************************************
* dummy task
*
**************************************************************************************************************/
/**********
void mswitch_task(int instance) {
	char * buf;
	int index;
	char * data;

	if (instance == 1) {
		CMS_set_init_status(TASK, OK);
		semGive(cms_init_sem);
		taskSuspend(0);
	}

	while (1) {
		if ((index = receiveMessage(TASK, WAIT_FOREVER, buf)) == -1) {
			cout << "error - receiveMessage" << endl;
		} else {
			cout << "index = " << index << endl;
		}
		printBCB(index);

		data = getData(index);
		cout << "data = " << data;

		freeBuffer(index);
		printBCB(index);
	}
}

void mswitch_task1(int instance) {
	char * ptr;
	int index;
	BUFFER_HEADER * header;
	char * data;

	if (instance == 1) {

		CMS_set_init_status(TASK1, OK);
		semGive(cms_init_sem);
		taskSuspend(0);
	}

	if ((index = getBuffer(256, ptr)) == -1) {
		cout << "can not get the buffer" << endl;
	} else {
		cout << "index = " << index << endl;
	}

	printBCB(index);

	header = getBufferHeader(index);

	header->srcTaskId = TASK1;
	header->dstTaskId = TASK;
	header->verison = 1;
	header->release = 1;
	header->msgType = 1;

	data = getData(index);
	strcpy(data, "This is the test\n");
	header->length = sizeof(BUFFER_HEADER) + 18;
	int handle = startTimer(3, index, 1);
	printTimerList();
	taskDelay(12000);
	stopTimer(handle);
	printTimerList();
}
********/


